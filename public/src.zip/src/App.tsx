import Home from "./pages/Home.tsx";

const App = () => {
  return (
    <div>
      <Home/>
    </div>
  )
}

export default App