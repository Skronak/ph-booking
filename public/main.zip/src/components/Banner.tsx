import {Container, Nav, Navbar} from 'react-bootstrap';
import './banner.css';
import {useTranslation} from "react-i18next";

const Banner = () => {
    const [t] = useTranslation();

    return (
        <Navbar bg="transparent" expand="lg">
            <Container className={"navbar-container"}>
                <Navbar.Brand href="#">Vuez Cocoon House</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav"/>
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="me-auto">
                        <Nav.Link href="#section-features">{t("menuHouse")}</Nav.Link>
                        <Nav.Link href="#section-gallery">{t("menuGallery")}</Nav.Link>
                        <Nav.Link href="#section-gmap">{t("menuLocation")}</Nav.Link>
                        <Nav.Link href="#section-explore">{t("menuSurroundings")}</Nav.Link>
                        <Nav.Link href="#section-contact">{t("menuContact")}</Nav.Link>
                    </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
}
export default Banner;