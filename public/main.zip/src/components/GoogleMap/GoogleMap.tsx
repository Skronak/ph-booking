import {Container} from "react-bootstrap";

export function GoogleMap() {

    return (
            <Container>
                <h2 className={"section-title"}>House location</h2><span></span>
                <img style={{width: "19em"}} src={"/gmap.PNG"}/>
            </Container>
    )
}
