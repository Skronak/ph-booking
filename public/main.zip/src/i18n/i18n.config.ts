import i18next from 'i18next';
import { initReactI18next } from 'react-i18next';
import locale_en from './en/locales.json';
import locale_fr from './fr/locales.json';

i18next.use(initReactI18next).init({
  lng: 'en', // default langage
  interpolation: {
    escapeValue: false,
  },
  resources: {
    en: {translation: {...locale_en}},
    fr: {translation:{...locale_fr}},
  },
});

export default i18next;